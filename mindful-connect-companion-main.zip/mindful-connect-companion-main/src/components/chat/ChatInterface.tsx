
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Send, Mic, Volume2 } from 'lucide-react';

type Message = {
  id: string;
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
};

const ChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hello! I'm your wellness companion. How are you feeling today?",
      sender: 'assistant',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = () => {
    if (input.trim()) {
      // Add user message
      const userMessage: Message = {
        id: Date.now().toString(),
        content: input,
        sender: 'user',
        timestamp: new Date(),
      };
      setMessages([...messages, userMessage]);
      setInput('');
      
      // Simulate assistant response after a short delay
      setTimeout(() => {
        const assistantResponse = generateResponse(input);
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: assistantResponse,
          sender: 'assistant',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, assistantMessage]);
      }, 1000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // Simulating voice recording start
      setTimeout(() => {
        setIsRecording(false);
        setMessages(prev => [
          ...prev, 
          {
            id: Date.now().toString(),
            content: "I'm feeling a bit lonely today.",
            sender: 'user',
            timestamp: new Date(),
          }
        ]);
        
        // Simulate assistant response after a short delay
        setTimeout(() => {
          const assistantMessage: Message = {
            id: (Date.now() + 1).toString(),
            content: "I understand feeling lonely can be difficult. Would you like to chat for a bit, or perhaps I can suggest some activities that might help?",
            sender: 'assistant',
            timestamp: new Date(),
          };
          setMessages(prev => [...prev, assistantMessage]);
        }, 1000);
      }, 2000);
    }
  };

  // Simple response generator
  const generateResponse = (input: string) => {
    const responses = [
      "I understand how you feel. Would you like to talk more about it?",
      "Thank you for sharing that with me. How can I support you today?",
      "I'm here to listen. Would you like some suggestions that might help?",
      "Let's explore that further. What do you think might help in this situation?",
      "I appreciate you opening up. Would you like to try an activity that might help?"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  };

  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-8rem)]">
      <Card className="flex-1 overflow-y-auto p-4 mb-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'assistant' ? 'justify-start' : 'justify-end'}`}
            >
              <div
                className={
                  message.sender === 'assistant'
                    ? 'chat-bubble-assistant animate-fade-in'
                    : 'chat-bubble-user animate-fade-in'
                }
              >
                {message.content}
                <div className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </Card>

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          className={`rounded-full ${isRecording ? 'bg-red-100 text-red-500 animate-pulse' : ''}`}
          onClick={toggleRecording}
        >
          <Mic className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          className="rounded-full"
        >
          <Volume2 className="h-4 w-4" />
        </Button>
        <Input
          placeholder="Type your message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          className="flex-1 rounded-full"
        />
        <Button
          onClick={handleSend}
          className="rounded-full bg-wellness-purple hover:bg-wellness-purple/90"
          disabled={!input.trim()}
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default ChatInterface;
