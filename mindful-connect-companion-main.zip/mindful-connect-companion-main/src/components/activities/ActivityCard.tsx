
import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Clock, Award, Tag } from 'lucide-react';

export interface ActivityProps {
  title: string;
  description: string;
  image: string;
  duration: string;
  category: string;
  level: string;
  onClick?: () => void;
}

const ActivityCard: React.FC<ActivityProps> = ({
  title,
  description,
  image,
  duration,
  category,
  level,
  onClick,
}) => {
  return (
    <Card className="overflow-hidden h-full flex flex-col border-wellness-purple/10 hover:border-wellness-purple/30 transition-all">
      <div className="aspect-video w-full overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
      </div>
      <CardContent className="flex-1 pt-4">
        <h3 className="font-medium text-lg mb-2">{title}</h3>
        <p className="text-muted-foreground text-sm mb-3">{description}</p>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <Tag className="h-3 w-3" />
            <span>{category}</span>
          </div>
          <div className="flex items-center gap-1">
            <Award className="h-3 w-3" />
            <span>{level}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={onClick} 
          variant="outline" 
          className="w-full border-wellness-purple/20 hover:bg-wellness-purple/5 hover:text-wellness-purple"
        >
          Start Activity
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ActivityCard;
