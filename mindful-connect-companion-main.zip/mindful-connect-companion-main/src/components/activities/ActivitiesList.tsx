
import React from 'react';
import ActivityCard, { ActivityProps } from './ActivityCard';
import { useToast } from '@/hooks/use-toast';

const ActivitiesList = () => {
  const { toast } = useToast();
  
  // Sample data for activities
  const activities: ActivityProps[] = [
    {
      title: "Guided Meditation",
      description: "A gentle 10-minute meditation to reduce anxiety and improve focus",
      image: "https://images.unsplash.com/photo-1545389336-cf090694435e?q=80&w=500&auto=format&fit=crop",
      duration: "10 mins",
      category: "Mindfulness",
      level: "Beginner",
    },
    {
      title: "Classical Music Session",
      description: "Relax with a curated playlist of classical music favorites",
      image: "https://images.unsplash.com/photo-1507838153414-b4b713384a76?q=80&w=500&auto=format&fit=crop",
      duration: "30 mins",
      category: "Music",
      level: "All Levels",
    },
    {
      title: "Virtual Museum Tour",
      description: "Visit world-famous museums from the comfort of your home",
      image: "https://images.unsplash.com/photo-1605429523419-d828acb941d9?q=80&w=500&auto=format&fit=crop",
      duration: "45 mins",
      category: "Culture",
      level: "All Levels",
    },
    {
      title: "Gentle Chair Yoga",
      description: "Easy stretching exercises you can do while seated",
      image: "https://images.unsplash.com/photo-1616699002805-0741e1e4a9c5?q=80&w=500&auto=format&fit=crop",
      duration: "15 mins",
      category: "Movement",
      level: "Beginner",
    },
    {
      title: "Digital Book Club",
      description: "Join this week's discussion on 'The Power of Now'",
      image: "https://images.unsplash.com/photo-1474932430478-367dbb6832c1?q=80&w=500&auto=format&fit=crop",
      duration: "1 hour",
      category: "Reading",
      level: "All Levels",
    },
    {
      title: "Bird Watching Guide",
      description: "Learn to identify common birds in your area",
      image: "https://images.unsplash.com/photo-1452570053594-1b985d6ea890?q=80&w=500&auto=format&fit=crop",
      duration: "20 mins",
      category: "Nature",
      level: "Beginner",
    },
  ];

  const handleActivityClick = (activity: ActivityProps) => {
    toast({
      title: "Activity Selected",
      description: `You selected: ${activity.title}`,
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {activities.map((activity, index) => (
        <ActivityCard
          key={index}
          {...activity}
          onClick={() => handleActivityClick(activity)}
        />
      ))}
    </div>
  );
};

export default ActivitiesList;
