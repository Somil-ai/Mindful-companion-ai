
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

const SettingsForm = () => {
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated.",
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-wellness-purple/10">
        <CardHeader>
          <CardTitle>Profile Settings</CardTitle>
          <CardDescription>Manage your personal information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" defaultValue="Jane Doe" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" defaultValue="jane.doe@example.com" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="interests">Interests</Label>
            <Input id="interests" defaultValue="Reading, Music, Gardening, Puzzles" />
            <p className="text-sm text-muted-foreground">Comma-separated list of your interests</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-wellness-purple/10">
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
          <CardDescription>Control how and when you receive notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Connection Reminders</p>
              <p className="text-sm text-muted-foreground">Notifications about upcoming scheduled connections</p>
            </div>
            <Switch defaultChecked />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Activity Suggestions</p>
              <p className="text-sm text-muted-foreground">Notifications about new personalized activities</p>
            </div>
            <Switch defaultChecked />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Wellness Check-ins</p>
              <p className="text-sm text-muted-foreground">Regular reminders to update your mood</p>
            </div>
            <Switch />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="reminder-time">Preferred Reminder Time</Label>
            <Select defaultValue="morning">
              <SelectTrigger>
                <SelectValue placeholder="Select time of day" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="morning">Morning (8:00 AM - 10:00 AM)</SelectItem>
                <SelectItem value="afternoon">Afternoon (12:00 PM - 2:00 PM)</SelectItem>
                <SelectItem value="evening">Evening (6:00 PM - 8:00 PM)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-wellness-purple/10">
        <CardHeader>
          <CardTitle>Privacy & Accessibility</CardTitle>
          <CardDescription>Control your data and app experience</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Larger Text</p>
              <p className="text-sm text-muted-foreground">Increase text size for better readability</p>
            </div>
            <Switch />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">High Contrast Mode</p>
              <p className="text-sm text-muted-foreground">Improve visibility with higher contrast colors</p>
            </div>
            <Switch />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Data Collection</p>
              <p className="text-sm text-muted-foreground">Allow anonymous usage data to improve our service</p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>
      
      <div className="flex justify-end gap-4">
        <Button variant="outline">Cancel</Button>
        <Button className="bg-wellness-purple hover:bg-wellness-purple/90" onClick={handleSave}>Save Changes</Button>
      </div>
    </div>
  );
};

export default SettingsForm;
