
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Video, Phone, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const ConnectScheduler = () => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [contactName, setContactName] = useState('');
  const [connectionType, setConnectionType] = useState('video');
  const [time, setTime] = useState('');
  const { toast } = useToast();

  const handleSchedule = () => {
    if (!contactName || !time) {
      toast({
        title: "Missing Information",
        description: "Please complete all fields",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Connection Scheduled!",
      description: `${connectionType} call with ${contactName} scheduled for ${date?.toLocaleDateString()} at ${time}`,
    });
    
    // Reset form
    setContactName('');
    setTime('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2 border-wellness-purple/10">
        <CardHeader>
          <CardTitle>Schedule a Connection</CardTitle>
          <CardDescription>Stay connected with your loved ones</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="contact-name">Contact Name</Label>
                <Input 
                  id="contact-name" 
                  placeholder="Enter name" 
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Connection Type</Label>
                <div className="flex gap-3">
                  <Button 
                    type="button"
                    variant={connectionType === 'video' ? 'default' : 'outline'} 
                    className={connectionType === 'video' ? 'bg-wellness-purple hover:bg-wellness-purple/90' : ''}
                    onClick={() => setConnectionType('video')}
                  >
                    <Video className="mr-2 h-4 w-4" />
                    Video Call
                  </Button>
                  <Button 
                    type="button"
                    variant={connectionType === 'phone' ? 'default' : 'outline'}
                    className={connectionType === 'phone' ? 'bg-wellness-purple hover:bg-wellness-purple/90' : ''}
                    onClick={() => setConnectionType('phone')}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    Phone Call
                  </Button>
                  <Button 
                    type="button"
                    variant={connectionType === 'group' ? 'default' : 'outline'}
                    className={connectionType === 'group' ? 'bg-wellness-purple hover:bg-wellness-purple/90' : ''}
                    onClick={() => setConnectionType('group')}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    Group
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="time">Time</Label>
                <Input 
                  id="time" 
                  type="time" 
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleSchedule}
                className="w-full bg-wellness-purple hover:bg-wellness-purple/90"
              >
                Schedule Connection
              </Button>
            </div>
            
            <div>
              <Label>Date</Label>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-wellness-purple/10">
        <CardHeader>
          <CardTitle>Recent Connections</CardTitle>
          <CardDescription>Stay in touch regularly</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-full bg-blue-100">
                  <Video className="h-4 w-4 text-blue-700" />
                </div>
                <div>
                  <p className="font-medium">Video call with Family</p>
                  <p className="text-xs text-muted-foreground">Yesterday, 3:00 PM</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-sm w-full mt-1">
                Schedule Again
              </Button>
            </div>
            
            <div className="bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-full bg-green-100">
                  <Phone className="h-4 w-4 text-green-700" />
                </div>
                <div>
                  <p className="font-medium">Call with Sarah</p>
                  <p className="text-xs text-muted-foreground">April 8, 2025, 10:30 AM</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-sm w-full mt-1">
                Schedule Again
              </Button>
            </div>
            
            <div className="bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-full bg-purple-100">
                  <Users className="h-4 w-4 text-purple-700" />
                </div>
                <div>
                  <p className="font-medium">Book Club Meeting</p>
                  <p className="text-xs text-muted-foreground">April 5, 2025, 2:00 PM</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-sm w-full mt-1">
                Schedule Again
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ConnectScheduler;
