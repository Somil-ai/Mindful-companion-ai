
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Smile, Meh, Frown, Heart, ThumbsUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

const MoodTracker = () => {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const { toast } = useToast();
  
  const moods = [
    { icon: Smile, label: 'Great', color: 'text-green-500' },
    { icon: ThumbsUp, label: 'Good', color: 'text-blue-500' },
    { icon: Meh, label: 'Okay', color: 'text-yellow-500' },
    { icon: Frown, label: 'Not Great', color: 'text-orange-500' },
    { icon: Heart, label: 'Loved', color: 'text-pink-500' },
  ];

  const handleMoodSelection = (mood: string) => {
    setSelectedMood(mood);
    toast({
      title: 'Mood Updated',
      description: `You're feeling ${mood} today.`,
    });
  };

  return (
    <Card className="w-full shadow-sm border-wellness-purple/10">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-medium">How are you feeling today?</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-4 justify-between">
          {moods.map((mood) => (
            <Button
              key={mood.label}
              variant="ghost"
              className={cn(
                "flex flex-col items-center gap-2 h-auto py-4 transition-all",
                selectedMood === mood.label ? "bg-wellness-purple/10 scale-105" : ""
              )}
              onClick={() => handleMoodSelection(mood.label)}
            >
              <mood.icon className={cn("w-8 h-8", mood.color)} />
              <span className={cn(
                "text-sm font-medium",
                selectedMood === mood.label ? "text-wellness-purple" : ""
              )}>
                {mood.label}
              </span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default MoodTracker;
