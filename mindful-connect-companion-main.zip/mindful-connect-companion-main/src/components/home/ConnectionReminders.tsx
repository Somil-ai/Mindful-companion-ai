
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Calendar, Video, Phone, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const ConnectionReminders = () => {
  const { toast } = useToast();
  
  const upcomingConnections = [
    {
      title: "Video Call with Family",
      time: "Today, 2:00 PM",
      type: "video",
    },
    {
      title: "Weekly Check-in with Sarah",
      time: "Tomorrow, 10:00 AM",
      type: "phone",
    },
    {
      title: "Birthday Reminder: James",
      time: "May 15, 2025",
      type: "calendar",
    },
  ];

  const handleReminderAction = (title: string) => {
    toast({
      title: "Reminder Set",
      description: `You'll be notified before "${title}"`,
    });
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="h-4 w-4" />;
      case 'phone':
        return <Phone className="h-4 w-4" />;
      case 'calendar':
        return <Calendar className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <Card className="w-full shadow-sm border-wellness-purple/10 mt-6">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-medium">Upcoming Connections</CardTitle>
        <CardDescription>
          Stay in touch with your loved ones
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {upcomingConnections.map((connection, index) => (
            <div key={index} className="flex items-center justify-between bg-secondary rounded-lg p-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-wellness-purple/20">
                  {getIcon(connection.type)}
                </div>
                <div>
                  <p className="font-medium">{connection.title}</p>
                  <p className="text-sm text-muted-foreground">{connection.time}</p>
                </div>
              </div>
              <Button 
                size="sm" 
                variant="ghost" 
                className="text-wellness-purple hover:bg-wellness-purple/10"
                onClick={() => handleReminderAction(connection.title)}
              >
                Remind Me
              </Button>
            </div>
          ))}
          <Button variant="outline" className="w-full border-dashed border-wellness-purple/20">
            + Add New Reminder
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ConnectionReminders;
