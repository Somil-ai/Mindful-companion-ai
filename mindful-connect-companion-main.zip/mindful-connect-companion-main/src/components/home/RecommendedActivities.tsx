
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Music, Headphones, Users, Radio, BookOpen, Film } from 'lucide-react';
import { cn } from '@/lib/utils';

const RecommendedActivities = () => {
  const activities = [
    {
      icon: Music,
      title: "Music Therapy",
      description: "Listen to calming melodies to improve your mood",
      color: "bg-wellness-soft-blue"
    },
    {
      icon: Headphones,
      title: "Guided Meditation",
      description: "Reduce stress with a 5-minute guided session",
      color: "bg-wellness-soft-green"
    },
    {
      icon: Users,
      title: "Virtual Social Club",
      description: "Join others with similar interests for a chat",
      color: "bg-wellness-soft-pink"
    },
    {
      icon: Radio,
      title: "Podcast Discovery",
      description: "Discover podcasts about topics you enjoy",
      color: "bg-wellness-soft-yellow"
    },
    {
      icon: BookOpen,
      title: "Digital Book Club",
      description: "Weekly book discussions with community",
      color: "bg-wellness-light-purple"
    },
    {
      icon: Film,
      title: "Movie Night",
      description: "Watch a film with synchronized viewing and chat",
      color: "bg-wellness-soft-blue"
    },
  ];

  return (
    <Card className="w-full shadow-sm border-wellness-purple/10 mt-6">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-medium">Recommended Activities</CardTitle>
        <CardDescription>
          Personalized suggestions to boost your well-being
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {activities.map((activity, index) => (
            <Card 
              key={index} 
              className="group cursor-pointer hover:shadow-md transition-all border-wellness-purple/10"
            >
              <CardContent className="p-4 flex items-start space-x-4">
                <div className={cn("p-2 rounded-md", activity.color)}>
                  <activity.icon className="h-5 w-5" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-medium group-hover:text-wellness-purple transition-colors">
                    {activity.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {activity.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecommendedActivities;
