
import React from 'react';
import { Button } from '@/components/ui/button';
import { MessageSquare, Music, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';

const WelcomeSection = () => {
  // Get greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 18) return "Good Afternoon";
    return "Good Evening";
  };
  
  // Get random supportive message
  const getSupportiveMessage = () => {
    const messages = [
      "Remember, you're never alone. I'm here for you.",
      "Every conversation is a step towards feeling connected.",
      "Taking time for yourself today is an act of self-care.",
      "I'm here to listen whenever you need me.",
      "Your wellbeing matters. How can I support you today?"
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  return (
    <div className="space-y-6 mb-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">{getGreeting()}</h1>
        <p className="text-muted-foreground mt-1">{getSupportiveMessage()}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button asChild variant="outline" className="h-auto py-6 flex flex-col items-center gap-3 border-wellness-purple/20 hover:border-wellness-purple hover:bg-wellness-purple/5">
          <Link to="/chat">
            <MessageSquare className="h-8 w-8 text-wellness-purple" />
            <span className="font-medium">Start a Conversation</span>
          </Link>
        </Button>
        
        <Button asChild variant="outline" className="h-auto py-6 flex flex-col items-center gap-3 border-wellness-purple/20 hover:border-wellness-purple hover:bg-wellness-purple/5">
          <Link to="/activities">
            <Music className="h-8 w-8 text-wellness-purple" />
            <span className="font-medium">Discover Activities</span>
          </Link>
        </Button>
        
        <Button asChild variant="outline" className="h-auto py-6 flex flex-col items-center gap-3 border-wellness-purple/20 hover:border-wellness-purple hover:bg-wellness-purple/5">
          <Link to="/connect">
            <Calendar className="h-8 w-8 text-wellness-purple" />
            <span className="font-medium">Schedule Connection</span>
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default WelcomeSection;
