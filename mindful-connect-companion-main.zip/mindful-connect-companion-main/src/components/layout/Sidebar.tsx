
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, MessageCircle, Calendar, Music, Activity, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  mobile?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ mobile = false }) => {
  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: MessageCircle, label: 'Chat', path: '/chat' },
    { icon: Activity, label: 'Activities', path: '/activities' },
    { icon: Calendar, label: 'Connect', path: '/connect' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  if (mobile) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-background border-t z-10">
        <div className="flex items-center justify-around p-2">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex flex-col items-center justify-center p-2 rounded-md transition-colors",
                isActive ? "text-wellness-purple" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <item.icon size={20} />
              <span className="text-xs mt-1">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="w-64 border-r bg-background hidden md:block">
      <div className="flex flex-col h-full py-6">
        <div className="px-6 mb-8">
          <h2 className="text-xl font-bold text-wellness-purple flex items-center">
            <Activity className="mr-2" size={24} />
            MindfulCompanion
          </h2>
        </div>
        
        <div className="space-y-1 px-3 flex-1">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center px-3 py-2 rounded-lg transition-colors",
                isActive 
                  ? "bg-wellness-purple text-white" 
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <item.icon className="mr-3" size={18} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>
        
        <div className="mt-auto px-6 py-4">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary">
            <div className="w-10 h-10 rounded-full bg-wellness-purple flex items-center justify-center text-white">
              ME
            </div>
            <div>
              <p className="font-medium text-sm">My Profile</p>
              <p className="text-xs text-muted-foreground">Manage settings</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
