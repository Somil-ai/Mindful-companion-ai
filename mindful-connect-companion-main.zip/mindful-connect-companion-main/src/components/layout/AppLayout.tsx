
import React, { ReactNode } from 'react';
import Sidebar from './Sidebar';
import { useIsMobile } from '@/hooks/use-mobile';

interface AppLayoutProps {
  children: ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const isMobile = useIsMobile();
  
  return (
    <div className="flex min-h-screen bg-background">
      {!isMobile && <Sidebar />}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        {children}
      </main>
      {isMobile && <Sidebar mobile />}
    </div>
  );
};

export default AppLayout;
