
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import ActivitiesList from '@/components/activities/ActivitiesList';

const Activities = () => {
  return (
    <AppLayout>
      <h1 className="text-2xl font-bold mb-2">Recommended Activities</h1>
      <p className="text-muted-foreground mb-6">Discover personalized activities to boost your well-being</p>
      
      <ActivitiesList />
    </AppLayout>
  );
};

export default Activities;
