
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import ChatInterface from '@/components/chat/ChatInterface';

const Chat = () => {
  return (
    <AppLayout>
      <div className="h-[calc(100vh-8rem)]">
        <h1 className="text-2xl font-bold mb-4">Conversation</h1>
        <ChatInterface />
      </div>
    </AppLayout>
  );
};

export default Chat;
