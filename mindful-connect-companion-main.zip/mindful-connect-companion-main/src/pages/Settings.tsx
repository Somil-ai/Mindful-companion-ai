
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import SettingsForm from '@/components/settings/SettingsForm';

const Settings = () => {
  return (
    <AppLayout>
      <h1 className="text-2xl font-bold mb-2">Settings</h1>
      <p className="text-muted-foreground mb-6">Customize your experience and preferences</p>
      
      <SettingsForm />
    </AppLayout>
  );
};

export default Settings;
