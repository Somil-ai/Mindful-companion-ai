
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import WelcomeSection from '@/components/home/WelcomeSection';
import MoodTracker from '@/components/home/MoodTracker';
import RecommendedActivities from '@/components/home/RecommendedActivities';
import ConnectionReminders from '@/components/home/ConnectionReminders';

const Index = () => {
  return (
    <AppLayout>
      <WelcomeSection />
      <MoodTracker />
      <RecommendedActivities />
      <ConnectionReminders />
    </AppLayout>
  );
};

export default Index;
