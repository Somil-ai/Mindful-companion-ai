
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import ConnectScheduler from '@/components/connect/ConnectScheduler';

const Connect = () => {
  return (
    <AppLayout>
      <h1 className="text-2xl font-bold mb-2">Connect With Others</h1>
      <p className="text-muted-foreground mb-6">Schedule video calls and stay connected with your loved ones</p>
      
      <ConnectScheduler />
    </AppLayout>
  );
};

export default Connect;
